<?php

//phpinfo();
echo "yasir";
?>