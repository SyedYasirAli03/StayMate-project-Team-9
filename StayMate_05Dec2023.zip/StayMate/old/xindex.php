<!DOCTYPE html>
<html>
    <head>
    </head>
    <style>
        body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        }

        .full-page {
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        background-color: #2A3950;
        }
    </style>
<body>
    <div class="full-page">
    <div style="text-align:center">        
        <img src="images/landing.jpg" alt=""/>
    </div>
    <div>
</body>
</html>
