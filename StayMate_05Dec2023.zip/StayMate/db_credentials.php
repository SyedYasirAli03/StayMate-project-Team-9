<?php
// Replace 'your_db_host', 'your_db_username', 'your_db_password', and 'your_db_name'
// with your actual database connection details.
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'staymate_db_user');
define('DB_PASSWORD', 'P@55w0rd123');
define('DB_NAME', 'staymate_db');
define('MAIL_USER_PWD', '}JsftmwvV?q1');
define('MAIL_SERVER', 'mail.trainings4u.com');
define('MAIL_USERNAME', 'yasir@trainings4u.com');
define('MAIL_SERVER_PORT', '587');
?>
